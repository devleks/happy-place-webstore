# Agent Personas & CI Workflows - Installation Package

**Version:** 2.0  
**For Project:** Happy Place Webstore  
**Date:** December 2024

---

## 📦 Package Contents

This package contains all agent personas and CI workflow scripts organized for easy installation into your project.

### Directory Structure

```
organized_package/
├── setup.sh                    # Automated installation script
├── README.md                   # This file
├── personas/                   # Agent persona documentation (10 files)
│   ├── AGENT_PERSONAS_README.md
│   ├── AGENT_TEAMS.md          # Main overview document
│   ├── agent-developer.md
│   ├── agent-code-reviewer.md
│   ├── agent-rebaser.md
│   ├── agent-merger.md
│   ├── agent-multiplan-manager.md
│   ├── agent-initializer.md
│   ├── agent-execution.md
│   └── agent-review-validation.md
│
└── ci_workflows/               # CI agent scripts & documentation
    ├── optimized_agent_lintguard.sh
    ├── optimized_agent_shieldprobe.sh
    ├── optimized_agent_perfsmith.sh
    ├── optimized_agent_schemasage.sh
    ├── optimized_agent_atlasreporter.sh
    ├── run_agents_locally.sh
    ├── AGENT_PERSONA_CI_MAPPING.md
    ├── AGENT_OPTIMIZATION_GUIDE.md
    ├── HELPER_OPTIMIZATION_GUIDE.md
    ├── WHERE_AGENTS_RUN.md
    ├── WORKFLOW_COMPARISON.md
    ├── MACOS_OPTIMIZATION_GUIDE.md
    └── helpers/
        ├── optimized_perfsmith_hotspots.py
        └── optimized_schemasage_explain.sql
```

---

## 🚀 Installation

### Option 1: Automated Installation (Recommended)

```bash
# Navigate to the organized_package directory
cd organized_package

# Make setup script executable
chmod +x setup.sh

# Run the setup script
./setup.sh
```

The script will:
- ✅ Create necessary directories in your project
- ✅ Copy all persona files to `.promptx/personas/`
- ✅ Copy all CI scripts to `ci_workflows/`
- ✅ Copy helper files to `ci_workflows/helpers/`
- ✅ Make all scripts executable
- ✅ Display installation summary

### Option 2: Manual Installation

```bash
# Set your project root
PROJECT_ROOT="/Users/xreatives/Documents/Code/cli_projects/happy_place_webstore"

# Create directories
mkdir -p "$PROJECT_ROOT/.promptx/personas"
mkdir -p "$PROJECT_ROOT/ci_workflows/helpers"

# Copy persona files
cp personas/*.md "$PROJECT_ROOT/.promptx/personas/"

# Copy CI workflow scripts
cp ci_workflows/*.sh "$PROJECT_ROOT/ci_workflows/"
chmod +x "$PROJECT_ROOT/ci_workflows/"*.sh

# Copy documentation
cp ci_workflows/*.md "$PROJECT_ROOT/ci_workflows/"

# Copy helpers
cp ci_workflows/helpers/* "$PROJECT_ROOT/ci_workflows/helpers/"
```

---

## 📚 What Gets Installed

### 1. Agent Personas (→ `.promptx/personas/`)

**8 comprehensive agent personas** (169KB total):
- **agent-developer.md** (20KB) - Daily development with CI integration
- **agent-code-reviewer.md** (22KB) - Systematic code reviews
- **agent-rebaser.md** (22KB) - Git history management
- **agent-merger.md** (23KB) - Branch integration strategies
- **agent-multiplan-manager.md** (23KB) - Complex project orchestration
- **agent-initializer.md** (21KB) - Goal definition & baselines
- **agent-execution.md** (19KB) - Focused implementation
- **agent-review-validation.md** (19KB) - Validation & decisions

**Documentation:**
- **AGENT_TEAMS.md** - Main overview document
- **AGENT_PERSONAS_README.md** - Quick reference guide

### 2. CI Workflow Scripts (→ `ci_workflows/`)

**5 optimized CI agents:**
- `optimized_agent_lintguard.sh` (11KB) - Code quality (8s runtime)
- `optimized_agent_shieldprobe.sh` (14KB) - Security scanning (25s)
- `optimized_agent_perfsmith.sh` (12KB) - Performance analysis (15s)
- `optimized_agent_schemasage.sh` (12KB) - Database optimization (18s)
- `optimized_agent_atlasreporter.sh` (15KB) - Consolidated reporting (3s)

**Orchestration:**
- `run_agents_locally.sh` (8KB) - Run all agents in parallel

**Documentation:**
- `AGENT_PERSONA_CI_MAPPING.md` - Complete integration guide
- `AGENT_OPTIMIZATION_GUIDE.md` - Performance & optimization
- `HELPER_OPTIMIZATION_GUIDE.md` - Helper file details
- `WHERE_AGENTS_RUN.md` - Execution context explanation
- `WORKFLOW_COMPARISON.md` - Parallel vs serial comparison
- `MACOS_OPTIMIZATION_GUIDE.md` - macOS-specific optimizations

### 3. Helper Files (→ `ci_workflows/helpers/`)

- `optimized_perfsmith_hotspots.py` (18KB) - Performance analysis tool
- `optimized_schemasage_explain.sql` (13KB) - Database diagnostic queries

---

## ✅ Post-Installation Verification

After running the setup script, verify the installation:

```bash
# Check persona files
ls -l ~/.promptx/personas/agent-*.md | wc -l
# Should show: 8

# Check CI scripts
ls -l ~/path/to/project/ci_workflows/*.sh | wc -l
# Should show: 6

# Check helpers
ls -l ~/path/to/project/ci_workflows/helpers/
# Should show: 2 files

# Test CI script execution
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore
./ci_workflows/run_agents_locally.sh --help
# Should display help message
```

---

## 🎯 Quick Start After Installation

### 1. Read the Overview

```bash
# Main overview document
open .promptx/personas/AGENT_TEAMS.md

# Quick reference
open .promptx/personas/AGENT_PERSONAS_README.md
```

### 2. Start with Developer Persona

```bash
# Most commonly used persona
open .promptx/personas/agent-developer.md
```

### 3. Try Running CI Agents

```bash
# From your project root
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore

# Run all CI agents in parallel (~45s total)
./ci_workflows/run_agents_locally.sh --parallel

# Run individual agents for quick feedback
./ci_workflows/optimized_agent_lintguard.sh  # 8s - Quick code quality check
```

### 4. Understand CI Integration

```bash
# Read the complete integration guide
open ci_workflows/AGENT_PERSONA_CI_MAPPING.md
```

---

## 📖 Documentation Reading Order

### For Developers
1. `AGENT_TEAMS.md` - Overview
2. `agent-developer.md` - Start here
3. `AGENT_PERSONA_CI_MAPPING.md` - CI integration
4. `agent-review-validation.md` - Before committing

### For Reviewers
1. `agent-code-reviewer.md` - Review process
2. `AGENT_PERSONA_CI_MAPPING.md` - Using CI in reviews
3. `agent-review-validation.md` - Final validation

### For Project Leads
1. `AGENT_TEAMS.md` - System overview
2. `agent-multiplan-manager.md` - Complex projects
3. `agent-initializer.md` - Starting projects right

---

## 🔧 Troubleshooting

### Issue: Scripts won't execute

```bash
# Make scripts executable
chmod +x ci_workflows/*.sh
```

### Issue: Python scripts fail

```bash
# Install dependencies
pip3 install radon --break-system-packages  # For PerfSmith
```

### Issue: Database scripts need connection

```bash
# Set DATABASE_URL before running SchemaSage
export DATABASE_URL="postgresql://user:pass@localhost/dbname"
./ci_workflows/optimized_agent_schemasage.sh
```

### Issue: Paths don't match

Edit `setup.sh` and update `PROJECT_ROOT` to your actual project path:
```bash
PROJECT_ROOT="/your/actual/project/path"
```

---

## 💡 Tips

### Create Aliases for Quick Access

Add to your `~/.zshrc` or `~/.bashrc`:

```bash
# Navigate to project
alias cdweb='cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore'

# Run CI checks
alias ci-quick='./ci_workflows/optimized_agent_lintguard.sh'
alias ci-full='./ci_workflows/run_agents_locally.sh --parallel'
alias ci-help='./ci_workflows/run_agents_locally.sh --help'

# View personas
alias persona-dev='open .promptx/personas/agent-developer.md'
alias persona-review='open .promptx/personas/agent-code-reviewer.md'
alias persona-list='ls -1 .promptx/personas/agent-*.md'
```

### Integration with Git Hooks

```bash
# Create pre-commit hook
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
./ci_workflows/optimized_agent_lintguard.sh
if [ $(jq '.summary.critical' reports/lintguard.json) -gt 0 ]; then
    echo "❌ Critical issues found - commit blocked"
    exit 1
fi
EOF

chmod +x .git/hooks/pre-commit
```

---

## 📞 Support

### Documentation
- **Main guide:** `AGENT_TEAMS.md`
- **Quick reference:** `AGENT_PERSONAS_README.md`
- **CI integration:** `AGENT_PERSONA_CI_MAPPING.md`

### Common Workflows
- Daily development → `agent-developer.md`
- Code review → `agent-code-reviewer.md`
- Before commit → `agent-review-validation.md`
- Git cleanup → `agent-rebaser.md`
- Merging → `agent-merger.md`

---

## 🎉 You're All Set!

After installation:
- ✅ 8 comprehensive agent personas in `.promptx/personas/`
- ✅ 5 optimized CI agents in `ci_workflows/`
- ✅ Complete documentation and guides
- ✅ Ready to use immediately

**Start with:** `open .promptx/personas/AGENT_TEAMS.md`

Happy coding! 🚀
