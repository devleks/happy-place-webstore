# 🚀 Installation Guide - Agent Personas & CI Workflows

**Package:** organized_package  
**For Project:** Happy Place Webstore  
**Installation Path:** `/Users/xreatives/Documents/Code/cli_projects/happy_place_webstore`

---

## 📦 What You Have

The `organized_package` directory contains everything organized and ready to install:

```
organized_package/
├── setup.sh                    ← Automated installation script
├── README.md                   ← Detailed package documentation
├── personas/                   ← 10 agent persona files (169KB)
└── ci_workflows/               ← 6 CI scripts + docs + helpers
```

---

## ✅ Installation Steps

### Step 1: Download the Package

The `organized_package` folder has been created in `/mnt/user-data/outputs/organized_package/`

Download this entire folder to your local machine.

### Step 2: Navigate to the Package

```bash
cd ~/Downloads/organized_package  # Or wherever you downloaded it
```

### Step 3: Make Setup Script Executable

```bash
chmod +x setup.sh
```

### Step 4: Review the Script (Optional but Recommended)

```bash
# Review what the script will do
cat setup.sh

# The script will copy files to:
# - .promptx/personas/     ← Agent persona markdown files
# - ci_workflows/          ← CI agent scripts
# - ci_workflows/helpers/  ← Python/SQL helper files
```

### Step 5: Run the Setup Script

```bash
./setup.sh
```

**Output will show:**
```
╔══════════════════════════════════════════════════════════════╗
║   Agent Personas & CI Workflows Setup Script                ║
╚══════════════════════════════════════════════════════════════╝

✓ Project directory found: /Users/xreatives/.../happy_place_webstore

Creating directories...
✓ Directories created

Installing Agent Personas...
✓ Installed 10 agent persona files

Installing CI Workflow Scripts...
✓ Installed 6 CI workflow scripts
✓ Made scripts executable

Installing CI Documentation...
✓ Installed 6 documentation files

Installing Helper Files...
✓ Installed 2 helper files

╔══════════════════════════════════════════════════════════════╗
║   Installation Complete!                                     ║
╚══════════════════════════════════════════════════════════════╝

📁 Files installed to:
   Agent Personas: .../.promptx/personas/
   CI Workflows:   .../ci_workflows/
   Helpers:        .../ci_workflows/helpers/
```

---

## 🎯 Verification

After installation, verify everything is in place:

```bash
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore

# Check personas (should show 10 files)
ls -1 .promptx/personas/

# Check CI scripts (should show 6 .sh files)
ls -1 ci_workflows/*.sh

# Check helpers (should show 2 files)
ls -1 ci_workflows/helpers/

# Test a script
./ci_workflows/run_agents_locally.sh --help
```

**Expected output:**
```
.promptx/personas/:
  AGENT_PERSONAS_README.md
  AGENT_TEAMS.md
  agent-code-reviewer.md
  agent-developer.md
  agent-execution.md
  agent-initializer.md
  agent-merger.md
  agent-multiplan-manager.md
  agent-rebaser.md
  agent-review-validation.md

ci_workflows/:
  optimized_agent_atlasreporter.sh
  optimized_agent_lintguard.sh
  optimized_agent_perfsmith.sh
  optimized_agent_schemasage.sh
  optimized_agent_shieldprobe.sh
  run_agents_locally.sh

ci_workflows/helpers/:
  optimized_perfsmith_hotspots.py
  optimized_schemasage_explain.sql
```

---

## 🚀 Quick Start After Installation

### 1. Read the Main Overview

```bash
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore

# Open the main guide
open .promptx/personas/AGENT_TEAMS.md
```

### 2. Start with Developer Persona

```bash
# Most commonly used persona for daily development
open .promptx/personas/agent-developer.md
```

### 3. Try Running CI Agents

```bash
# Quick code quality check (8 seconds)
./ci_workflows/optimized_agent_lintguard.sh

# Full CI validation (45 seconds, runs all agents in parallel)
./ci_workflows/run_agents_locally.sh --parallel
```

### 4. Review the Results

```bash
# Reports are created in the reports/ directory
ls -la reports/

# View summary
cat reports/weekly_agent_digest.md
```

---

## 📁 What Gets Installed Where

### To: `.promptx/personas/` (Agent Persona Documentation)

| File | Size | Purpose |
|------|------|---------|
| **AGENT_TEAMS.md** | 18KB | 📘 Main overview document - **Start here!** |
| **AGENT_PERSONAS_README.md** | 5KB | Quick reference guide |
| agent-developer.md | 20KB | Daily development with CI integration |
| agent-code-reviewer.md | 22KB | Systematic code reviews |
| agent-rebaser.md | 22KB | Git history cleanup |
| agent-merger.md | 23KB | Branch integration |
| agent-multiplan-manager.md | 23KB | Complex project coordination |
| agent-initializer.md | 21KB | Goal definition & baselines |
| agent-execution.md | 19KB | Focused implementation |
| agent-review-validation.md | 19KB | Validation & commit decisions |

**Total:** 10 files, 192KB

### To: `ci_workflows/` (CI Agent Scripts & Documentation)

**Scripts:**
| File | Runtime | Purpose |
|------|---------|---------|
| optimized_agent_lintguard.sh | 8s | Code quality validation |
| optimized_agent_shieldprobe.sh | 25s | Security scanning |
| optimized_agent_perfsmith.sh | 15s | Performance analysis |
| optimized_agent_schemasage.sh | 18s | Database optimization |
| optimized_agent_atlasreporter.sh | 3s | Consolidated reporting |
| run_agents_locally.sh | 45s | Orchestration (runs all in parallel) |

**Documentation:**
- AGENT_PERSONA_CI_MAPPING.md - Complete integration guide
- AGENT_OPTIMIZATION_GUIDE.md - Performance details
- HELPER_OPTIMIZATION_GUIDE.md - Helper file documentation
- WHERE_AGENTS_RUN.md - Execution context explained
- WORKFLOW_COMPARISON.md - Parallel vs serial
- MACOS_OPTIMIZATION_GUIDE.md - macOS-specific optimizations

### To: `ci_workflows/helpers/` (Helper Tools)

- optimized_perfsmith_hotspots.py - Python performance analyzer
- optimized_schemasage_explain.sql - SQL diagnostic queries

---

## 💡 Pro Tips

### Create Command Aliases

Add to your `~/.zshrc`:

```bash
# Project navigation
alias cdweb='cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore'

# CI commands
alias ci='cdweb && ./ci_workflows/run_agents_locally.sh --parallel'
alias ci-lint='cdweb && ./ci_workflows/optimized_agent_lintguard.sh'
alias ci-sec='cdweb && ./ci_workflows/optimized_agent_shieldprobe.sh'
alias ci-perf='cdweb && ./ci_workflows/optimized_agent_perfsmith.sh'

# Documentation
alias personas='open .promptx/personas/AGENT_TEAMS.md'
alias persona-dev='open .promptx/personas/agent-developer.md'
```

Then reload:
```bash
source ~/.zshrc
```

### Add Git Pre-Commit Hook

```bash
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore

# Create pre-commit hook
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
./ci_workflows/optimized_agent_lintguard.sh
CRITICAL=$(jq '.summary.critical' reports/lintguard.json 2>/dev/null || echo "0")
if [ "$CRITICAL" -gt 0 ]; then
    echo "❌ Critical issues found - commit blocked"
    exit 1
fi
EOF

chmod +x .git/hooks/pre-commit
```

### VS Code Integration

Create `.vscode/tasks.json`:

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Run CI: Quick Lint",
      "type": "shell",
      "command": "./ci_workflows/optimized_agent_lintguard.sh",
      "group": "test",
      "presentation": {
        "reveal": "always"
      }
    },
    {
      "label": "Run CI: Full Suite",
      "type": "shell",
      "command": "./ci_workflows/run_agents_locally.sh --parallel",
      "group": "test",
      "presentation": {
        "reveal": "always"
      }
    }
  ]
}
```

---

## 🔧 Troubleshooting

### Issue: setup.sh won't run

```bash
# Make it executable
chmod +x setup.sh

# If still fails, check if you're in the right directory
pwd  # Should show: .../organized_package
```

### Issue: Project directory not found

Edit `setup.sh` and update the PROJECT_ROOT variable:

```bash
# Line 11 in setup.sh
PROJECT_ROOT="/your/actual/project/path"
```

### Issue: Scripts won't execute after installation

```bash
cd /Users/xreatives/Documents/Code/cli_projects/happy_place_webstore
chmod +x ci_workflows/*.sh
```

### Issue: Python dependencies missing

```bash
# Install dependencies for PerfSmith
pip3 install radon --break-system-packages
```

### Issue: Database connection needed

```bash
# Set DATABASE_URL for SchemaSage
export DATABASE_URL="postgresql://user:pass@localhost/dbname"
./ci_workflows/optimized_agent_schemasage.sh
```

---

## 📖 Learning Path

### Week 1: Getting Started
1. Read `AGENT_TEAMS.md` - Overview
2. Read `agent-developer.md` - Most practical
3. Try running `./ci_workflows/run_agents_locally.sh --parallel`
4. Review the reports in `reports/`

### Week 2: Daily Usage
1. Use Developer Agent workflow during coding
2. Run LintGuard before commits
3. Practice Review/Validation Agent checklist
4. Read `AGENT_PERSONA_CI_MAPPING.md`

### Week 3: Advanced Workflows
1. Learn Rebaser Agent for Git cleanup
2. Study Merger Agent strategies
3. Try Multiplan Manager for complex work

### Week 4: Team Integration
1. Share personas with team
2. Set up Git hooks
3. Integrate into PR process
4. Customize for your workflow

---

## ✅ Installation Checklist

Before you start:
- [ ] Downloaded organized_package folder
- [ ] Navigated to organized_package directory
- [ ] Made setup.sh executable (`chmod +x setup.sh`)

Running setup:
- [ ] Executed `./setup.sh`
- [ ] Saw success messages for all installations
- [ ] Verified files in `.promptx/personas/`
- [ ] Verified scripts in `ci_workflows/`

After installation:
- [ ] Read `AGENT_TEAMS.md`
- [ ] Tested `./ci_workflows/run_agents_locally.sh --help`
- [ ] Tried running a quick lint check
- [ ] Created command aliases (optional)

---

## 🎉 You're Ready!

Once installation is complete, you'll have:
- ✅ 10 comprehensive agent personas
- ✅ 6 optimized CI workflow scripts
- ✅ Complete documentation
- ✅ Helper tools and utilities

**Everything is ready to use immediately!**

Start with: `open .promptx/personas/AGENT_TEAMS.md`

Happy coding with AI-assisted workflows! 🚀
