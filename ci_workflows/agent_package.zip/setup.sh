#!/bin/bash
# Setup script for Happy Place Webstore Agent Personas & CI Workflows
# Run this script from the organized_package directory

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Project root directory
PROJECT_ROOT="/Users/xreatives/Documents/Code/cli_projects/happy_place_webstore"

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Agent Personas & CI Workflows Setup Script                ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if project directory exists
if [ ! -d "$PROJECT_ROOT" ]; then
    echo -e "${RED}❌ Error: Project directory not found: $PROJECT_ROOT${NC}"
    echo ""
    echo "Please update PROJECT_ROOT in this script to point to your project."
    exit 1
fi

echo -e "${GREEN}✓ Project directory found: $PROJECT_ROOT${NC}"
echo ""

# Create necessary directories
echo -e "${YELLOW}Creating directories...${NC}"
mkdir -p "$PROJECT_ROOT/.promptx/personas"
mkdir -p "$PROJECT_ROOT/ci_workflows/helpers"
echo -e "${GREEN}✓ Directories created${NC}"
echo ""

# Copy agent persona files
echo -e "${YELLOW}Installing Agent Personas...${NC}"
PERSONA_COUNT=$(ls personas/*.md 2>/dev/null | wc -l)
if [ "$PERSONA_COUNT" -gt 0 ]; then
    cp -v personas/*.md "$PROJECT_ROOT/.promptx/personas/"
    echo -e "${GREEN}✓ Installed $PERSONA_COUNT agent persona files${NC}"
else
    echo -e "${RED}❌ No persona files found in personas/ directory${NC}"
fi
echo ""

# Copy CI workflow scripts
echo -e "${YELLOW}Installing CI Workflow Scripts...${NC}"
SCRIPT_COUNT=$(ls ci_workflows/*.sh 2>/dev/null | wc -l)
if [ "$SCRIPT_COUNT" -gt 0 ]; then
    cp -v ci_workflows/*.sh "$PROJECT_ROOT/ci_workflows/"
    # Make scripts executable
    chmod +x "$PROJECT_ROOT/ci_workflows/"*.sh
    echo -e "${GREEN}✓ Installed $SCRIPT_COUNT CI workflow scripts${NC}"
    echo -e "${GREEN}✓ Made scripts executable${NC}"
else
    echo -e "${RED}❌ No scripts found in ci_workflows/ directory${NC}"
fi
echo ""

# Copy CI workflow documentation
echo -e "${YELLOW}Installing CI Documentation...${NC}"
DOC_COUNT=$(ls ci_workflows/*.md 2>/dev/null | wc -l)
if [ "$DOC_COUNT" -gt 0 ]; then
    cp -v ci_workflows/*.md "$PROJECT_ROOT/ci_workflows/"
    echo -e "${GREEN}✓ Installed $DOC_COUNT documentation files${NC}"
else
    echo -e "${YELLOW}⚠ No documentation files found in ci_workflows/ directory${NC}"
fi
echo ""

# Copy helper files
echo -e "${YELLOW}Installing Helper Files...${NC}"
if [ -d "ci_workflows/helpers" ]; then
    HELPER_COUNT=$(ls ci_workflows/helpers/* 2>/dev/null | wc -l)
    if [ "$HELPER_COUNT" -gt 0 ]; then
        cp -v ci_workflows/helpers/* "$PROJECT_ROOT/ci_workflows/helpers/"
        echo -e "${GREEN}✓ Installed $HELPER_COUNT helper files${NC}"
    fi
else
    echo -e "${YELLOW}⚠ No helpers directory found${NC}"
fi
echo ""

# Summary
echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Installation Complete!                                     ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${GREEN}📁 Files installed to:${NC}"
echo "   Agent Personas: $PROJECT_ROOT/.promptx/personas/"
echo "   CI Workflows:   $PROJECT_ROOT/ci_workflows/"
echo "   Helpers:        $PROJECT_ROOT/ci_workflows/helpers/"
echo ""

echo -e "${GREEN}🚀 Quick Start:${NC}"
echo "   1. Read the overview:"
echo "      ${YELLOW}open $PROJECT_ROOT/.promptx/personas/AGENT_PERSONAS_README.md${NC}"
echo ""
echo "   2. Try running CI agents:"
echo "      ${YELLOW}cd $PROJECT_ROOT${NC}"
echo "      ${YELLOW}./ci_workflows/run_agents_locally.sh --help${NC}"
echo ""
echo "   3. Read persona documentation:"
echo "      ${YELLOW}open $PROJECT_ROOT/.promptx/personas/agent-developer.md${NC}"
echo ""

echo -e "${GREEN}📚 Main Documentation:${NC}"
echo "   • AGENT_TEAMS.md - Overview of agent teams"
echo "   • AGENT_PERSONAS_README.md - Quick reference guide"
echo "   • AGENT_PERSONA_CI_MAPPING.md - CI integration guide"
echo ""

echo -e "${GREEN}✅ Setup complete!${NC}"
